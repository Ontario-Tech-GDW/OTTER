#pragma once

#include <memory>
#include <GLM/glm.hpp>
#include <string>
using namespace std;


class Player
{

public:


	Player();
   ~Player();





private:







};

